love = True

while love == True:
    print("I LOVE YOUU")